<div class='reklPicture'>
<!-- <a href='https://artargus.in.ua' target='_blank'>
  <img class="argusImg" src='/image/art.jpg' alt='товари для художників' title='все для художників' border='2'>
</a><br><br> -->
<img class="argusImg" src="/image/Logo_last.png">
</div>
<div>
	<a href="/insuranceAutosign" class="btn btn-primary btn-block">
		Авто номера
	</a>
	<a href="/insurance" class="btn btn-primary btn-block">
		Калькулятор автоцивілки
	</a>
		<a href="/calcLength" class="btn btn-primary btn-block">
		калькулятори інші
	</a>
</div>